const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const startBtn = document.getElementById('start-camera');
const captureBtn = document.getElementById('capture');
const downloadLink = document.getElementById('download');
const ctx = canvas.getContext('2d');

startBtn.addEventListener('click', async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true });
    video.srcObject = stream;
  } catch (err) {
    alert("Camera access is required.");
    console.error("Error accessing camera: ", err);
  }
});

captureBtn.addEventListener('click', () => {
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  ctx.drawImage(video, 0, 0);
  const imageData = canvas.toDataURL('image/png');
  downloadLink.href = imageData;
});